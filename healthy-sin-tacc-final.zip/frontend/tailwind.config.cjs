module.exports = { content: ['./index.html','./src/**/*.{js,jsx,ts,tsx}'], theme: { extend: { colors:{ brandGreen:'#1e7a3a', brandOrange:'#ff7a18' } } }, plugins: [], }
