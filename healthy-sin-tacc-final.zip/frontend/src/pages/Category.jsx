import React from 'react'
export default function Category(){ return (<div className='p-6'><h1 className='text-3xl'>Categoría</h1></div>) }
