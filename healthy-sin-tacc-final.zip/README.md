Proyecto healthy-sin-tacc - frontend + netlify functions

Instrucciones:
cd frontend
npm install
npm run dev

Setear ENVs en Netlify: ADMIN_EMAIL, ADMIN_PASS, JWT_SECRET
WhatsApp: 5491122850681
